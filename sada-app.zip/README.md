# صدى 🎧 — مشغل موسيقى MP3

## الرفع إلى GitHub
فك الضغط، ثم ارفع **محتويات** المجلد (وليس المجلد نفسه) إلى جذر المستودع، بحيث يظهر `package.json` و`www` مباشرة.

## ⚠️ مجلد .github مخفي
إذا ما ظهر `.github/workflows/build.yml` في مستودعك:
Add file ← Create new file، اكتب الاسم `.github/workflows/build.yml` والصق محتوى الملف `build-workflow.yml` ثم Commit.

## الحصول على APK
Actions ← Build APK ← Run workflow (أو يشتغل تلقائيًا مع كل رفع). بعد النجاح نزّل **sada-apk** من Artifacts وثبّت app-debug.apk.
