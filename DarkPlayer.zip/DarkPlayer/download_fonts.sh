#!/usr/bin/env bash
# يحمّل خط Tajawal (مجاني - OFL) إلى مجلد الخطوط. يعمل تلقائياً داخل GitHub Actions.
set -e
d=app/src/main/res/font
mkdir -p "$d"
b=https://raw.githubusercontent.com/google/fonts/main/ofl/tajawal
for w in Regular Medium Bold; do
  curl -fsSL --retry 3 -o "$d/tajawal_$(echo $w | tr A-Z a-z).ttf" "$b/Tajawal-$w.ttf"
done
ls -la "$d"
