package com.dark.player

import android.content.Intent
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null
    override fun onCreate() {
        super.onCreate()
        Eng.init(this)
        session = MediaSession.Builder(this, Eng.ex).build()
    }
    override fun onGetSession(c: MediaSession.ControllerInfo) = session
    override fun onTaskRemoved(rootIntent: Intent?) {
        if (!Eng.ex.playWhenReady) stopSelf()
    }
    override fun onDestroy() {
        session?.release(); session = null
        super.onDestroy()
    }
}
