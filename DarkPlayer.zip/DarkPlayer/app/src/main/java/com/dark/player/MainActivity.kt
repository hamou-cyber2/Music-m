package com.dark.player

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.core.content.ContextCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import coil.compose.SubcomposeAsyncImage
import android.app.Activity
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.widget.Toast
import androidx.activity.result.IntentSenderRequest
import androidx.compose.foundation.lazy.rememberLazyListState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.*

val Green = Color(0xFF1ED760)
val Card = Color(0xFF121212)
val F = FontFamily(
    Font(R.font.tajawal_regular, FontWeight.Normal),
    Font(R.font.tajawal_medium, FontWeight.Medium),
    Font(R.font.tajawal_bold, FontWeight.Bold)
)
private fun TextStyle.f() = copy(fontFamily = F)
fun appTypography(): Typography {
    val t = Typography()
    return Typography(
        displayLarge = t.displayLarge.f(), displayMedium = t.displayMedium.f(), displaySmall = t.displaySmall.f(),
        headlineLarge = t.headlineLarge.f(), headlineMedium = t.headlineMedium.f(), headlineSmall = t.headlineSmall.f(),
        titleLarge = t.titleLarge.f(), titleMedium = t.titleMedium.f(), titleSmall = t.titleSmall.f(),
        bodyLarge = t.bodyLarge.f(), bodyMedium = t.bodyMedium.f(), bodySmall = t.bodySmall.f(),
        labelLarge = t.labelLarge.f(), labelMedium = t.labelMedium.f(), labelSmall = t.labelSmall.f()
    )
}

data class Song(val id: Long, val title: String, val artist: String, val dur: Long, val uri: Uri, val art: Uri, val path: String = "", val size: Long = 0)

fun fmt(ms: Long): String {
    val s = ms / 1000
    return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60)
    else "%d:%02d".format(s / 60, s % 60)
}
fun fmtShort(ms: Long): String { val m = ms / 60000; return if (m >= 60) "%.1fس".format(m / 60f) else "${m}د" }

val dayNames = arrayOf("أحد", "اثنين", "ثلاثاء", "أربعاء", "خميس", "جمعة", "سبت")
val monthNames = arrayOf("ينا", "فبر", "مار", "أبر", "ماي", "يون", "يول", "أغس", "سبت", "أكت", "نوف", "ديس")
fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
fun lastDays(n: Int): List<Pair<String, String>> {
    val f = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    return (n - 1 downTo 0).map {
        val c = Calendar.getInstance(); c.add(Calendar.DAY_OF_YEAR, -it)
        f.format(c.time) to dayNames[c.get(Calendar.DAY_OF_WEEK) - 1]
    }
}

object Store {
    lateinit var sp: SharedPreferences
    val favs = mutableStateListOf<Long>()
    val lists = mutableStateMapOf<String, List<Long>>()
    val times = mutableStateMapOf<Long, Long>()
    val daily = mutableStateMapOf<String, Long>()
    val daySong = mutableStateMapOf<String, Long>()
    var total by mutableStateOf(0L)

    fun init(c: Context) {
        if (::sp.isInitialized) return
        sp = c.getSharedPreferences("d", 0)
        total = sp.getLong("total", 0)
        favs.addAll(sp.getStringSet("fav", setOf())!!.map { it.toLong() })
        sp.getStringSet("pls", setOf())!!.forEach { n ->
            lists[n] = sp.getString("pl_$n", "")!!.split(",").filter { it.isNotEmpty() }.map { it.toLong() }
        }
        sp.all.forEach { (k, v) ->
            when {
                k.startsWith("t_") -> times[k.substring(2).toLong()] = v as Long
                k.startsWith("d_") -> daily[k.substring(2)] = v as Long
                k.startsWith("s_") -> daySong[k.substring(2)] = v as Long
            }
        }
    }
    fun toggleFav(id: Long) {
        if (id in favs) favs.remove(id) else favs.add(id)
        sp.edit().putStringSet("fav", favs.map { it.toString() }.toSet()).apply()
    }
    fun savePl(name: String, ids: List<Long>) {
        lists[name] = ids
        sp.edit().putStringSet("pls", lists.keys.toSet()).putString("pl_$name", ids.joinToString(",")).apply()
    }
    fun delPl(name: String) {
        lists.remove(name)
        sp.edit().putStringSet("pls", lists.keys.toSet()).remove("pl_$name").apply()
    }
    fun addTime(id: Long, ms: Long) {
        val d = today(); val sk = "$d|$id"
        times[id] = (times[id] ?: 0) + ms
        daily[d] = (daily[d] ?: 0) + ms
        daySong[sk] = (daySong[sk] ?: 0) + ms
        total += ms
        sp.edit().putLong("t_$id", times[id]!!).putLong("d_$d", daily[d]!!).putLong("s_$sk", daySong[sk]!!).putLong("total", total).apply()
    }
}

object Eng {
    lateinit var ex: ExoPlayer
    private lateinit var app: Context
    var queue = listOf<Song>()
    var current by mutableStateOf<Song?>(null)
    var playing by mutableStateOf(false)
    var pos by mutableStateOf(0L)
    var dur by mutableStateOf(1L)
    var shuffle by mutableStateOf(false)
    var repeat by mutableStateOf(0) // 0 إيقاف، 1 الكل، 2 أغنية واحدة
    var autoAdvance by mutableStateOf(true)
    var speed by mutableStateOf(1f)
    var sleepAt by mutableStateOf(0L)
    var sleepLeft by mutableStateOf(0L)
    private val h = Handler(Looper.getMainLooper())

    fun init(c: Context) {
        if (::ex.isInitialized) return
        app = c.applicationContext
        Store.init(app)
        ex = ExoPlayer.Builder(app)
            .setAudioAttributes(AudioAttributes.Builder().setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).setUsage(C.USAGE_MEDIA).build(), true)
            .setHandleAudioBecomingNoisy(true)
            .build()
        ex.setWakeMode(C.WAKE_MODE_LOCAL)
        autoAdvance = Store.sp.getBoolean("auto", true)
        shuffle = Store.sp.getBoolean("shuffle", false)
        repeat = Store.sp.getInt("repeat", 0)
        speed = Store.sp.getFloat("speed", 1f)
        applySettings()
        setupFx(ex.audioSessionId)
        ex.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(p: Boolean) { playing = p }
            override fun onAudioSessionIdChanged(audioSessionId: Int) { setupFx(audioSessionId) }
            override fun onMediaItemTransition(m: MediaItem?, r: Int) {
                current = queue.find { it.id.toString() == m?.mediaId }
            }
        })
        h.post(object : Runnable {
            override fun run() {
                pos = ex.currentPosition
                dur = if (ex.duration > 0) ex.duration else 1L
                if (ex.isPlaying) current?.let { Store.addTime(it.id, 1000) }
                if (sleepAt > 0) {
                    sleepLeft = sleepAt - System.currentTimeMillis()
                    if (sleepLeft <= 0) { ex.pause(); sleepAt = 0; sleepLeft = 0 }
                }
                h.postDelayed(this, 1000)
            }
        })
    }
    // ---------- المعادل الصوتي ----------
    private var eq: Equalizer? = null
    private var bass: BassBoost? = null
    var eqOn by mutableStateOf(false)
    var eqBands by mutableStateOf(0)
    var eqMin by mutableStateOf(-1500)
    var eqMax by mutableStateOf(1500)
    var freqs by mutableStateOf(listOf<Int>())
    var presets by mutableStateOf(listOf<String>())
    var bassOk by mutableStateOf(false)
    var bassLevel by mutableStateOf(0)
    val bandLevels = mutableStateListOf<Int>()

    private fun setupFx(id: Int) {
        if (id <= 0) return
        try {
            eq?.release(); bass?.release()
            val e = Equalizer(0, id); eq = e
            eqBands = e.numberOfBands.toInt()
            eqMin = e.bandLevelRange[0].toInt(); eqMax = e.bandLevelRange[1].toInt()
            freqs = (0 until eqBands).map { e.getCenterFreq(it.toShort()) / 1000 }
            presets = (0 until e.numberOfPresets.toInt()).map { e.getPresetName(it.toShort()) }
            if (bandLevels.size != eqBands) {
                bandLevels.clear()
                for (i in 0 until eqBands) bandLevels.add(Store.sp.getInt("eq_$i", 0))
            }
            eqOn = Store.sp.getBoolean("eq_on", false)
            bassLevel = Store.sp.getInt("bass", 0)
            val b = BassBoost(0, id); bass = b
            bassOk = b.strengthSupported
            applyFx()
        } catch (_: Exception) {}
    }
    fun applyFx() {
        try {
            eq?.let { e ->
                e.enabled = eqOn
                for (i in 0 until eqBands) e.setBandLevel(i.toShort(), bandLevels[i].toShort())
            }
            bass?.let { b ->
                b.enabled = eqOn && bassLevel > 0
                if (b.strengthSupported) b.setStrength(bassLevel.toShort())
            }
        } catch (_: Exception) {}
    }
    fun saveFx() {
        val ed = Store.sp.edit().putBoolean("eq_on", eqOn).putInt("bass", bassLevel)
        bandLevels.forEachIndexed { i, v -> ed.putInt("eq_$i", v) }
        ed.apply()
    }
    fun usePreset(i: Int) {
        try {
            val e = eq ?: return
            e.usePreset(i.toShort())
            for (b in 0 until eqBands) bandLevels[b] = e.getBandLevel(b.toShort()).toInt()
            eqOn = true; applyFx(); saveFx()
        } catch (_: Exception) {}
    }

    private fun applySettings() {
        ex.pauseAtEndOfMediaItems = !autoAdvance
        ex.shuffleModeEnabled = shuffle
        ex.repeatMode = when (repeat) { 1 -> Player.REPEAT_MODE_ALL; 2 -> Player.REPEAT_MODE_ONE; else -> Player.REPEAT_MODE_OFF }
        ex.setPlaybackSpeed(speed)
    }
    fun save() {
        Store.sp.edit().putBoolean("auto", autoAdvance).putBoolean("shuffle", shuffle)
            .putInt("repeat", repeat).putFloat("speed", speed).apply()
        applySettings()
    }
    fun play(list: List<Song>, i: Int) {
        queue = list
        ex.setMediaItems(list.map {
            MediaItem.Builder().setUri(it.uri).setMediaId(it.id.toString())
                .setMediaMetadata(MediaMetadata.Builder().setTitle(it.title).setArtist(it.artist).setArtworkUri(it.art).build())
                .build()
        }, i, 0)
        ex.prepare(); ex.play()
        current = list[i]
        try { ContextCompat.startForegroundService(app, Intent(app, PlaybackService::class.java)) } catch (_: Exception) {}
    }
    fun setSleep(min: Int) {
        sleepAt = if (min > 0) System.currentTimeMillis() + min * 60_000L else 0
        if (min == 0) sleepLeft = 0
    }
}

fun loadSongs(c: Context): List<Song> {
    val out = mutableListOf<Song>()
    val u = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
    val m = MediaStore.Audio.Media
    val p = arrayOf(m._ID, m.TITLE, m.ARTIST, m.DURATION, m.ALBUM_ID, m.DATA, m.SIZE)
    c.contentResolver.query(u, p, "${m.IS_MUSIC}!=0 AND ${m.DURATION}>30000", null, "${m.TITLE} COLLATE NOCASE")?.use {
        while (it.moveToNext()) {
            val id = it.getLong(0)
            out += Song(id, it.getString(1) ?: "?", it.getString(2) ?: "", it.getLong(3),
                ContentUris.withAppendedId(u, id),
                ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), it.getLong(4)), it.getString(5) ?: "", it.getLong(6))
        }
    }
    return out
}

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Eng.init(this)
        val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        val perms = buildList {
            add(perm)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        }.toTypedArray()
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(background = Color.Black, surface = Color.Black, primary = Green, onPrimary = Color.Black, surfaceVariant = Color(0xFF1A1A1A)),
                typography = appTypography()
            ) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    var ok by remember { mutableStateOf(ContextCompat.checkSelfPermission(this, perm) == PackageManager.PERMISSION_GRANTED) }
                    val l = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
                        ok = ContextCompat.checkSelfPermission(this, perm) == PackageManager.PERMISSION_GRANTED
                    }
                    LaunchedEffect(Unit) { if (!ok) l.launch(perms) }
                    Surface(Modifier.fillMaxSize(), color = Color.Black) {
                        if (ok) App() else Box(Modifier.fillMaxSize(), Alignment.Center) {
                            Button({ l.launch(perms) }) { Text("السماح بالوصول للموسيقى") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Art(uri: Uri, size: Dp, radius: Dp = 10.dp) {
    SubcomposeAsyncImage(model = uri, contentDescription = null, contentScale = ContentScale.Crop,
        modifier = Modifier.size(size).clip(RoundedCornerShape(radius)),
        loading = { ArtPh() }, error = { ArtPh() })
}

@Composable
fun ArtPh() = Box(
    Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Green.copy(alpha = 0.35f), Color(0xFF0B3D1E)))),
    Alignment.Center
) { Text("♪", color = Color.White, fontSize = 22.sp) }

@Composable
fun Header(t: String, sub: String = "") {
    Column(Modifier.padding(16.dp, 16.dp, 16.dp, 4.dp)) {
        Text(t, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        if (sub.isNotEmpty()) Text(sub, color = Color.Gray)
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    var songs by remember { mutableStateOf(loadSongs(ctx)) }
    var tab by remember { mutableStateOf(0) }
    var open by remember { mutableStateOf<String?>(null) }
    var dup by remember { mutableStateOf(false) }
    var q by remember { mutableStateOf("") }
    var byPlays by remember { mutableStateOf(false) }
    val names = listOf("الأغاني", "المجلدات", "القوائم", "المفضلة", "الإحصاءات")
    val icons = listOf("♪", "▤", "☰", "♥", "◔")
    BackHandler(dup || open != null) { if (dup) dup = false else open = null }
    if (dup) {
        Duplicates(songs, { dup = false }) { songs = loadSongs(ctx) }
    } else Scaffold(containerColor = Color.Black,
        bottomBar = {
            Column {
                MiniPlayer()
                NavigationBar(containerColor = Color(0xFF0D0D0D)) {
                    names.forEachIndexed { i, n ->
                        NavigationBarItem(selected = tab == i, onClick = { tab = i; open = null },
                            colors = NavigationBarItemDefaults.colors(indicatorColor = Green.copy(alpha = 0.2f), selectedTextColor = Green, selectedIconColor = Green),
                            icon = { Text(icons[i], fontSize = 20.sp) }, label = { Text(n, fontSize = 10.sp, maxLines = 1) })
                    }
                }
            }
        }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> {
                    var view = songs.filter { it.title.contains(q, true) || it.artist.contains(q, true) }
                    if (byPlays) view = view.sortedByDescending { Store.times[it.id] ?: 0 }
                    Column {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Header("مكتبتي", "${songs.size} أغنية")
                            TextButton({ dup = true }, Modifier.padding(horizontal = 8.dp)) { Text("🧹 المكررات") }
                        }
                        TextField(q, { q = it }, Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp).clip(RoundedCornerShape(14.dp)),
                            placeholder = { Text("ابحث عن أغنية أو فنان") }, singleLine = true,
                            colors = TextFieldDefaults.colors(focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent))
                        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(!byPlays, { byPlays = false }, { Text("الاسم") })
                            FilterChip(byPlays, { byPlays = true }, { Text("الأكثر استماعاً") })
                        }
                        SongList(view)
                    }
                }
                1 -> if (open == null) {
                    val groups = songs.groupBy { it.path.substringBeforeLast('/', "") }.entries.sortedBy { it.key.substringAfterLast('/').lowercase() }
                    Column {
                        Header("المجلدات", "${groups.size} مجلد")
                        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(groups) { g ->
                                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Card).clickable { open = g.key }.padding(16.dp)) {
                                    Text("📁 " + g.key.substringAfterLast('/'), fontWeight = FontWeight.Bold)
                                    Text("${g.value.size} أغنية • ${g.key}", color = Color.Gray, style = MaterialTheme.typography.bodySmall, maxLines = 1)
                                }
                            }
                        }
                    }
                } else {
                    val p = open!!
                    val list = songs.filter { it.path.substringBeforeLast('/', "") == p }
                    Column {
                        TextButton({ open = null }, Modifier.padding(horizontal = 8.dp)) { Text("→ رجوع") }
                        Header(p.substringAfterLast('/'), "${list.size} أغنية")
                        SongList(list)
                    }
                }
                2 -> if (open == null) Playlists { open = it }
                     else {
                         val n = open!!
                         val ids = Store.lists[n] ?: listOf()
                         Column {
                             TextButton({ open = null }, Modifier.padding(horizontal = 8.dp)) { Text("→ رجوع") }
                             Header(n, "${ids.size} أغنية")
                             SongList(ids.mapNotNull { id -> songs.find { it.id == id } }) { s -> Store.savePl(n, ids - s.id) }
                         }
                     }
                3 -> Column { Header("المفضلة"); SongList(songs.filter { it.id in Store.favs }) }
                else -> Stats(songs)
            }
        }
    }
}

fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

@Composable
fun Duplicates(songs: List<Song>, onBack: () -> Unit, onDeleted: () -> Unit) {
    val ctx = LocalContext.current
    val groups = remember(songs) {
        songs.groupBy { norm(it.title) + "|" + norm(it.artist) + "|" + it.dur / 5000 }
            .values.filter { it.size > 1 }.map { g -> g.sortedByDescending { it.size } }
    }
    val sel = remember(groups) { mutableStateListOf<Long>().apply { groups.forEach { g -> g.drop(1).forEach { add(it.id) } } } }
    val l = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) {
        if (it.resultCode == Activity.RESULT_OK) { Toast.makeText(ctx, "تم الحذف", Toast.LENGTH_SHORT).show(); onDeleted() }
    }
    fun doDelete() {
        val uris = songs.filter { it.id in sel }.map { it.uri }
        if (uris.isEmpty()) return
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                l.launch(IntentSenderRequest.Builder(MediaStore.createDeleteRequest(ctx.contentResolver, uris).intentSender).build())
            } else {
                uris.forEach { ctx.contentResolver.delete(it, null, null) }
                onDeleted()
            }
        } catch (e: Exception) { Toast.makeText(ctx, "تعذّر الحذف", Toast.LENGTH_SHORT).show() }
    }
    Column(Modifier.fillMaxSize().background(Color.Black)) {
        TextButton(onBack, Modifier.padding(horizontal = 8.dp)) { Text("→ رجوع") }
        Header("الأغاني المكررة", "${groups.size} مجموعة — الأكبر حجماً (الأفضل جودة) يبقى افتراضياً")
        if (groups.isEmpty()) Text("لا توجد أغانٍ مكررة ✓", Modifier.padding(16.dp), color = Green)
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(groups) { g ->
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Card).padding(8.dp)) {
                    g.forEachIndexed { i, s ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(s.id in sel, { if (it) sel.add(s.id) else sel.remove(s.id) })
                            Column(Modifier.weight(1f)) {
                                Text(s.title + if (i == 0) "  ★" else "", maxLines = 1, fontWeight = FontWeight.Medium)
                                Text("${s.path.substringBeforeLast('/').substringAfterLast('/')} • ${"%.1f".format(s.size / 1048576f)} MB • ${fmt(s.dur)}",
                                    color = Color.Gray, style = MaterialTheme.typography.bodySmall, maxLines = 1)
                            }
                        }
                    }
                }
            }
        }
        if (groups.isNotEmpty()) Button({ doDelete() }, Modifier.fillMaxWidth().padding(16.dp), enabled = sel.isNotEmpty()) { Text("حذف المحدد (${sel.size})") }
    }
}

@Composable
fun SongList(list: List<Song>, onRemove: ((Song) -> Unit)? = null) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(vertical = 8.dp)) {
        items(list, key = { it.id }) { s ->
            var menu by remember { mutableStateOf(false) }
            val cur = Eng.current?.id == s.id
            Row(Modifier.fillMaxWidth().clickable { Eng.play(list, list.indexOf(s)) }.padding(16.dp, 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Art(s.art, 52.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(s.title, maxLines = 1, fontWeight = FontWeight.Medium, color = if (cur) Green else Color.White)
                    Text("${s.artist} • ${fmt(s.dur)}", style = MaterialTheme.typography.bodySmall, color = Color.Gray, maxLines = 1)
                    val t = Store.times[s.id] ?: 0
                    if (t > 0) Text("استمعت: ${fmt(t)}", style = MaterialTheme.typography.labelSmall, color = Green.copy(alpha = 0.8f))
                }
                TextButton({ Store.toggleFav(s.id) }) { Text(if (s.id in Store.favs) "♥" else "♡", color = if (s.id in Store.favs) Green else Color.Gray, fontSize = 20.sp) }
                Box {
                    TextButton({ menu = true }) { Text("⋮", color = Color.Gray, fontSize = 20.sp) }
                    DropdownMenu(menu, { menu = false }) {
                        if (onRemove != null) DropdownMenuItem({ Text("حذف من القائمة") }, { onRemove(s); menu = false })
                        if (Store.lists.isEmpty()) DropdownMenuItem({ Text("أنشئ قائمة أولاً") }, { menu = false })
                        Store.lists.keys.forEach { n ->
                            DropdownMenuItem({ Text("إضافة إلى $n") }, {
                                val c = Store.lists[n] ?: listOf()
                                if (s.id !in c) Store.savePl(n, c + s.id)
                                menu = false
                            })
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Playlists(onOpen: (String) -> Unit) {
    var dlg by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        Header("قوائم التشغيل", "${Store.lists.size} قائمة")
        Button({ dlg = true }, Modifier.padding(horizontal = 16.dp)) { Text("+ قائمة جديدة") }
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(Store.lists.keys.toList()) { n ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Card).clickable { onOpen(n) }.padding(start = 16.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f).padding(vertical = 14.dp)) {
                        Text(n, fontWeight = FontWeight.Bold)
                        Text("${Store.lists[n]?.size ?: 0} أغنية", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                    }
                    TextButton({ Store.delPl(n) }) { Text("🗑") }
                }
            }
        }
    }
    if (dlg) AlertDialog(onDismissRequest = { dlg = false },
        title = { Text("اسم القائمة") },
        text = { TextField(name, { name = it }, singleLine = true) },
        confirmButton = { TextButton({ if (name.isNotBlank()) Store.savePl(name.trim(), listOf()); name = ""; dlg = false }) { Text("حفظ") } })
}

@Composable
fun StatCard(label: String, value: String, modifier: Modifier) {
    Column(modifier.clip(RoundedCornerShape(16.dp)).background(Card).padding(14.dp)) {
        Text(label, color = Color.Gray, style = MaterialTheme.typography.bodySmall)
        Text(value, color = Green, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
    }
}

@Composable
fun BarChart(bars: List<Pair<String, Long>>) {
    val mx = (bars.maxOfOrNull { it.second } ?: 0L).coerceAtLeast(1L)
    Row(Modifier.fillMaxWidth().height(170.dp).clip(RoundedCornerShape(16.dp)).background(Card).padding(12.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        bars.forEach { (l, v) ->
            Column(Modifier.weight(1f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                if (v > 0) Text(fmtShort(v), fontSize = 9.sp, color = Color.Gray, maxLines = 1)
                Box(Modifier.fillMaxWidth().fillMaxHeight(0.7f * v.toFloat() / mx.toFloat()).clip(RoundedCornerShape(6.dp))
                    .background(if (v > 0) Green else Color(0xFF2A2A2A)))
                Spacer(Modifier.height(4.dp))
                Text(l, fontSize = 10.sp, maxLines = 1)
            }
        }
    }
}

@Composable
fun Stats(songs: List<Song>) {
    var mode by remember { mutableStateOf(0) } // 0 أسبوع، 1 سنة، 2 الكل
    val year = remember { Calendar.getInstance().get(Calendar.YEAR) }
    val days = remember(mode) { lastDays(7) }
    val bars: List<Pair<String, Long>>
    val pred: (String) -> Boolean
    when (mode) {
        0 -> { bars = days.map { it.second to (Store.daily[it.first] ?: 0L) }; val set = days.map { it.first }.toSet(); pred = { d -> d in set } }
        1 -> {
            bars = (1..12).map { m -> val p = "%d-%02d".format(year, m); monthNames[m - 1] to Store.daily.filterKeys { it.startsWith(p) }.values.sum() }
            pred = { d -> d.startsWith("$year-") }
        }
        else -> { bars = emptyList(); pred = { true } }
    }
    val total = if (mode == 2) Store.total else bars.sumOf { it.second }
    val active = Store.daily.filter { pred(it.key) && it.value > 0 }.size
    val per: Map<Long, Long> = if (mode == 2) Store.times.toMap()
        else Store.daySong.entries.filter { pred(it.key.substringBefore('|')) }
            .groupBy({ it.key.substringAfter('|').toLong() }, { it.value }).mapValues { it.value.sum() }
    val top = per.entries.sortedByDescending { it.value }.take(20).mapNotNull { e -> songs.find { it.id == e.key }?.let { it to e.value } }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("الإحصاءات", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(mode == 0, { mode = 0 }, { Text("آخر 7 أيام") })
                FilterChip(mode == 1, { mode = 1 }, { Text("سنة $year") })
                FilterChip(mode == 2, { mode = 2 }, { Text("الكل") })
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("إجمالي الاستماع", fmt(total), Modifier.weight(1f))
                StatCard("المعدل اليومي", fmt(if (active > 0) total / active else 0), Modifier.weight(1f))
                StatCard("أيام نشطة", "$active", Modifier.weight(1f))
            }
        }
        if (bars.isNotEmpty()) item { BarChart(bars) }
        item { Text("الأكثر استماعاً", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium) }
        if (top.isEmpty()) item { Text("لا توجد بيانات بعد — شغّل بعض الأغاني!", color = Color.Gray) }
        items(top.size) { i ->
            val (s, t) = top[i]
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${i + 1}", Modifier.width(28.dp), color = Color.Gray)
                Art(s.art, 40.dp, 8.dp)
                Spacer(Modifier.width(10.dp))
                Text(s.title, Modifier.weight(1f), maxLines = 1)
                Text(fmt(t), color = Green)
            }
        }
    }
}

@Composable
fun MiniPlayer() {
    val s = Eng.current ?: return
    var open by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().background(Card).clickable { open = true }) {
        LinearProgressIndicator(progress = { (Eng.pos.toFloat() / Eng.dur.toFloat()).coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(2.dp), color = Green, trackColor = Color(0xFF2A2A2A))
        Row(Modifier.padding(12.dp, 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Art(s.art, 46.dp, 8.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(s.title, maxLines = 1, fontWeight = FontWeight.Medium)
                Text(s.artist, maxLines = 1, color = Color.Gray, style = MaterialTheme.typography.bodySmall)
            }
            TextButton({ if (Eng.ex.isPlaying) Eng.ex.pause() else Eng.ex.play() }) { Text(if (Eng.playing) "⏸" else "▶", fontSize = 24.sp) }
            TextButton({ Eng.ex.seekToNextMediaItem() }) { Text("⏭", fontSize = 24.sp) }
        }
    }
    if (open) NowPlaying(s) { open = false }
}

suspend fun fetchLyrics(ctx: Context, s: Song): String? = withContext(Dispatchers.IO) {
    val f = File(ctx.filesDir, "lyr_${s.id}.json")
    if (f.exists()) return@withContext f.readText()
    fun get(url: String): String? = try {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 8000
        c.setRequestProperty("User-Agent", "DarkPlayer/4.0")
        if (c.responseCode == 200) c.inputStream.bufferedReader().readText() else null
    } catch (e: Exception) { null }
    val artist = if (s.artist == "<unknown>") "" else s.artist
    fun enc(x: String) = URLEncoder.encode(x, "UTF-8")
    var out = get("https://lrclib.net/api/get?track_name=${enc(s.title)}&artist_name=${enc(artist)}&duration=${s.dur / 1000}")
    if (out == null) {
        val arr = get("https://lrclib.net/api/search?q=${enc(s.title + " " + artist)}")
        try { val a = JSONArray(arr ?: "[]"); if (a.length() > 0) out = a.getJSONObject(0).toString() } catch (_: Exception) {}
    }
    out?.also { f.writeText(it) }
}

fun lyricsField(raw: String?, key: String): String {
    if (raw == null) return ""
    return try { val o = JSONObject(raw); if (o.isNull(key)) "" else o.getString(key) } catch (e: Exception) { "" }
}

fun parseLrc(raw: String?): List<Pair<Long, String>> {
    val r = Regex("""^\[(\d+):(\d+(?:\.\d+)?)](.*)$""")
    return lyricsField(raw, "syncedLyrics").lines().mapNotNull { l ->
        r.find(l.trim())?.let { m ->
            val t = ((m.groupValues[1].toLong() * 60 + m.groupValues[2].toDouble()) * 1000).toLong()
            t to m.groupValues[3].trim()
        }
    }.filter { it.second.isNotEmpty() }
}

@Composable
fun LyricsView(s: Song) {
    val ctx = LocalContext.current
    var raw by remember(s.id) { mutableStateOf<String?>(null) }
    var loading by remember(s.id) { mutableStateOf(true) }
    LaunchedEffect(s.id) { loading = true; raw = fetchLyrics(ctx, s); loading = false }
    val synced = remember(raw) { parseLrc(raw) }
    val plain = remember(raw) { lyricsField(raw, "plainLyrics") }
    when {
        loading -> CircularProgressIndicator(color = Green)
        synced.isNotEmpty() -> {
            val st = rememberLazyListState()
            val idx = synced.indexOfLast { it.first <= Eng.pos + 700 }.coerceAtLeast(0)
            LaunchedEffect(idx) { st.animateScrollToItem((idx - 2).coerceAtLeast(0)) }
            LazyColumn(Modifier.fillMaxSize(), state = st, horizontalAlignment = Alignment.CenterHorizontally) {
                items(synced.size) { i ->
                    Text(synced[i].second, textAlign = TextAlign.Center,
                        fontSize = if (i == idx) 22.sp else 16.sp,
                        fontWeight = if (i == idx) FontWeight.Bold else FontWeight.Normal,
                        color = if (i == idx) Green else Color.Gray,
                        modifier = Modifier.padding(vertical = 8.dp).clickable { Eng.ex.seekTo(synced[i].first) })
                }
            }
        }
        plain.isNotEmpty() -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(plain, textAlign = TextAlign.Center, color = Color.White, lineHeight = 26.sp)
        }
        else -> Text("لم أجد كلمات لهذه الأغنية\n(تحتاج اتصالاً بالإنترنت)", textAlign = TextAlign.Center, color = Color.Gray)
    }
}

@Composable
fun EqView() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("تفعيل المعادل الصوتي", Modifier.weight(1f), fontWeight = FontWeight.Medium)
            Switch(Eng.eqOn, { Eng.eqOn = it; Eng.applyFx(); Eng.saveFx() })
        }
        if (Eng.eqBands == 0) {
            Text("المعادل غير جاهز — شغّل أغنية أولاً", color = Color.Gray, modifier = Modifier.padding(top = 16.dp))
        } else {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Eng.presets.forEachIndexed { i, n -> FilterChip(false, { Eng.usePreset(i) }, { Text(n) }) }
            }
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                for (i in 0 until Eng.eqBands) Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${Eng.freqs.getOrElse(i) { 0 }}Hz", Modifier.width(60.dp), color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                    Slider(Eng.bandLevels[i].toFloat(), { Eng.bandLevels[i] = it.toInt(); Eng.applyFx() },
                        Modifier.weight(1f), valueRange = Eng.eqMin.toFloat()..Eng.eqMax.toFloat(),
                        onValueChangeFinished = { Eng.saveFx() },
                        colors = SliderDefaults.colors(thumbColor = Green, activeTrackColor = Green))
                    Text("${Eng.bandLevels[i] / 100}dB", Modifier.width(48.dp), style = MaterialTheme.typography.bodySmall)
                }
                if (Eng.bassOk) Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("الجهير", Modifier.width(60.dp), color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                    Slider(Eng.bassLevel.toFloat(), { Eng.bassLevel = it.toInt(); Eng.applyFx() }, Modifier.weight(1f),
                        valueRange = 0f..1000f, onValueChangeFinished = { Eng.saveFx() },
                        colors = SliderDefaults.colors(thumbColor = Green, activeTrackColor = Green))
                    Text("${Eng.bassLevel / 10}%", Modifier.width(48.dp), style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
fun OptionsView() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Card).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("الانتقال التلقائي", fontWeight = FontWeight.Medium)
                Text(if (Eng.autoAdvance) "ينتقل للأغنية التالية تلقائياً" else "يتوقف بعد انتهاء كل أغنية", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
            }
            Switch(Eng.autoAdvance, { Eng.autoAdvance = it; Eng.save() })
        }
        Spacer(Modifier.height(12.dp))
        Text("سرعة التشغيل", fontWeight = FontWeight.Medium)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(0.75f, 1f, 1.25f, 1.5f, 2f).forEach { v -> FilterChip(Eng.speed == v, { Eng.speed = v; Eng.save() }, { Text("${v}x") }) }
        }
        Spacer(Modifier.height(8.dp))
        Text(if (Eng.sleepLeft > 0) "مؤقت النوم — متبقي ${Eng.sleepLeft / 60000 + 1} دقيقة" else "مؤقت النوم", fontWeight = FontWeight.Medium)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(15, 30, 60, 0).forEach { m -> FilterChip(false, { Eng.setSleep(m) }, { Text(if (m == 0) "إلغاء" else "$m د") }) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NowPlaying(s: Song, onClose: () -> Unit) {
    var page by remember { mutableStateOf(0) }
    ModalBottomSheet(onDismissRequest = onClose, containerColor = Color(0xFF0D0D0D),
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp).padding(bottom = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("الأغنية", "الكلمات", "المعادل", "خيارات").forEachIndexed { i, n -> FilterChip(page == i, { page = i }, { Text(n) }) }
            }
            Spacer(Modifier.height(12.dp))
            Box(Modifier.fillMaxWidth().height(300.dp), Alignment.Center) {
                when (page) {
                    0 -> Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Art(s.art, 220.dp, 24.dp)
                        Spacer(Modifier.height(12.dp))
                        Text(s.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 2, textAlign = TextAlign.Center)
                        Text(s.artist, color = Color.Gray)
                    }
                    1 -> LyricsView(s)
                    2 -> EqView()
                    else -> OptionsView()
                }
            }
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Slider(Eng.pos.toFloat().coerceIn(0f, Eng.dur.toFloat()), { Eng.ex.seekTo(it.toLong()); Eng.pos = it.toLong() },
                    valueRange = 0f..Eng.dur.toFloat(), colors = SliderDefaults.colors(thumbColor = Green, activeTrackColor = Green))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(fmt(Eng.pos), color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                    Text(fmt(Eng.dur), color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                    TextButton({ Eng.shuffle = !Eng.shuffle; Eng.save() }) { Text("⇄", fontSize = 24.sp, color = if (Eng.shuffle) Green else Color.Gray) }
                    TextButton({ Eng.ex.seekToPreviousMediaItem() }) { Text("⏮", fontSize = 28.sp) }
                    FilledIconButton({ if (Eng.ex.isPlaying) Eng.ex.pause() else Eng.ex.play() }, Modifier.size(64.dp),
                        colors = IconButtonDefaults.filledIconButtonColors(containerColor = Green, contentColor = Color.Black)) {
                        Text(if (Eng.playing) "⏸" else "▶", fontSize = 28.sp)
                    }
                    TextButton({ Eng.ex.seekToNextMediaItem() }) { Text("⏭", fontSize = 28.sp) }
                    TextButton({ Eng.repeat = (Eng.repeat + 1) % 3; Eng.save() }) {
                        Text(if (Eng.repeat == 2) "🔂" else "🔁", fontSize = 24.sp, color = if (Eng.repeat > 0) Green else Color.Gray)
                    }
                }
            }
        }
    }
}
